import boto3
import json
from kafka import KafkaConsumer

# Create a Kafka consumer
consumer = KafkaConsumer('Health-Alert-Messages', bootstrap_servers=['localhost:9092'], auto_offset_reset='earliest', value_deserializer=lambda m: m.decode('utf-8'))

# Create an SNS client using boto
sns_client = boto3.client('sns', region_name='us-east-1')

sns_topic_arn = 'arn:aws:sns:us-east-1:958232138250:Health-Alert-Notification'

# Publish messages to SNS topic
for message in consumer:
    try:
        message_obj = json.loads(message.value)
        subject_header = 'Health Alert: Patient- ' + message_obj['patientname']
        
        # Convert the message_obj dictionary to a JSON-formatted string
        message_str = json.dumps(message_obj)
        
        result = sns_client.publish(TopicArn=sns_topic_arn, Message=message_str, Subject=subject_header)
        print(result)
    except json.JSONDecodeError as e:
        # Handle JSON parsing errors here
        print(f"Error parsing JSON: {str(e)}")
    except KeyError as e:
        # Handle missing key errors here
        print(f"Key not found: {str(e)}")

